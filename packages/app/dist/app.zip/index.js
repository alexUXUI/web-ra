"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var app_exports = {};
__export(app_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(app_exports);
var import_chrome_aws_lambda = __toESM(require("chrome-aws-lambda"));
const handler = async (event, context, callback) => {
  let result = null;
  let browser = null;
  try {
    browser = await import_chrome_aws_lambda.default.puppeteer.launch({
      args: import_chrome_aws_lambda.default.args,
      defaultViewport: import_chrome_aws_lambda.default.defaultViewport,
      executablePath: await import_chrome_aws_lambda.default.executablePath,
      ignoreHTTPSErrors: true
    });
    if (browser === null) {
      throw new Error("Browser is null");
    }
    const page = await browser.newPage();
    const client = await page.target().createCDPSession();
    await client.send("Network.enable");
    await client.send("Page.enable");
    await client.send("Profiler.enable");
    await client.send("Debugger.enable");
    await client.send("Page.setWebLifecycleState", {
      state: "active"
    });
    await client.on("Page.lifecycleEvent", (event2) => {
      console.log(event2);
    });
    const url = event.url;
    await client.send("Profiler.startPreciseCoverage", {
      callCount: true,
      detailed: true
    });
    await page.goto(url ?? "https://boggle.pages.dev/");
    await client.on("Page.loadEventFired", () => {
      console.log("Page loaded");
    });
    const profile = await client.send("Profiler.takePreciseCoverage");
    const performanceTiming = JSON.parse(
      await page.evaluate(() => JSON.stringify(window.performance.timing))
    );
    const loadWithDOM = performanceTiming.domComplete - performanceTiming.navigationStart;
    const all = performanceTiming.loadEventEnd - performanceTiming.navigationStart;
    console.log(
      "User can see content for Regular2G ~",
      loadWithDOM / 1e3,
      "sec"
    );
    console.log("All Load for Regular2G --", all / 1e3, "sec");
    const title = await page.title();
    result = {
      // content,
      title: `${title}`,
      loadWithDOM,
      all,
      profile
    };
  } catch (error) {
    if (error instanceof Error) {
      console.error(error);
      return callback(error);
    }
  } finally {
    if (browser !== null) {
      await browser.close();
    }
  }
  return callback(null, result);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
